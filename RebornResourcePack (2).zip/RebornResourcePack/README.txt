RebornSMP Resource Pack

Custom fonts:
reborn:pixel
reborn:icons

Icons E000-E008:
E000 Player Head
E001 Rank
E002 Money
E003 Shards
E004 Keyall
E005 Playtime
E006 Kills
E007 Deaths
E008 Ping
